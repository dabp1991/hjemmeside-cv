﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections;
using System.Text.RegularExpressions;
using System.Text;

namespace BarbieAndKent
{
    ///  Denne klasse er en del af "Barbie & Kent" applikationen.
    /// "Barbie & Kent" er et simpelt tekstbaseret adventurespil. 
    /// 
    public class Score : IComparable<Score>
    {
        public string scoreName {get; set;}
        public int score { get; set; }

        public Score(string name, int newscore)
        {
            this.scoreName = name;
            this.score = newscore;
        }

        public int CompareTo(Score compareScore)
        {
            if (compareScore == null)
                return 1;

            else return this.score.CompareTo(compareScore.score);
        }
    }
}
