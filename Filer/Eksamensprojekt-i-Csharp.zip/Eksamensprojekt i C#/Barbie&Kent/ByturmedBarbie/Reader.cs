﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;

namespace BarbieAndKent
{
    public class Reader  
    {
        string currentGame = @"..\..\Properties\CurrentGame.txt";

        /// <summary>
        ///  Denne klasse er en del af "Barbie & Kent" applikationen.
        /// "Barbie & Kent" er et simpelt tekstbaseret adventurespil. 
        /// 
        /// Henter et givent rum navn
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public string getRoomName(string path)
        {
            using (StreamReader reader = new StreamReader(path))
            {

                while (!reader.EndOfStream)
                {
                    string room = reader.ReadLine();
                    string[] roomProperties = room.Split('#');
                    if (roomProperties[0] == "CURRENTROOM")
                    {
                        return roomProperties[2]; 
                    }
                }
                return null;
            }
        }

        /// <summary>
        /// Henter alt info fra et gemt spil og setter inventory, vægt og sletter items fra rum.
        /// </summary>
        /// <param name="currentPerson"></param>
        /// <param name="allRooms"></param>
        public void setSaveGame(Person currentPerson, Dictionary<string, Room> allRooms, Dictionary<string, Character> allCharacters, Dictionary<int, string> allTransports)
        {
            using (StreamReader reader = new StreamReader(currentGame))
            {
                // Finder personen i dokumentet og gemmer den i currentPerson fieldet i game klassen.
                reader.BaseStream.Position = 0;
                while (!reader.EndOfStream)
                {
                    string person = reader.ReadLine();
                    string[] personProperties = person.Split('#');
                    if (personProperties[0] == "PERSON")
                    { 
                        currentPerson.myWeight = Convert.ToInt32(personProperties[1]);
                        currentPerson.scoreName = personProperties[2];
                        currentPerson.currentScore = Convert.ToInt32(personProperties[3]);
                        currentPerson.drunkness = Convert.ToInt32(personProperties[4]);
                        currentPerson.Mæthed = Convert.ToInt32(personProperties[5]);
                        currentPerson.difficulty = personProperties[6];
                    }
                }

                // Tilføjer rum, karakterer, transport properties eller exits hvis de ikke er der.
               reader.BaseStream.Position = 0;
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    Room testRoom;
                    Character newCharacter;
                    string[] lineProperties = line.Split('#');
                    if (lineProperties[0] == "ROOM" && !allRooms.ContainsKey(lineProperties[2]))
                    {
                        string room = lineProperties[2];
                        string roomInfo = lineProperties[1];
                        Room roomToAdd = new Room(roomInfo, room, Convert.ToBoolean(lineProperties[3]));
                        allRooms.Add(room, roomToAdd);
                    }
                    else if (lineProperties[0] == "CHARACTER" && !allCharacters.ContainsKey(lineProperties[1]))
                    {
                        testRoom = allRooms[lineProperties[2]];
                        newCharacter = new Character(testRoom, lineProperties[1], lineProperties[3]);
                        testRoom.setCharacter(newCharacter);
                        allCharacters.Add(lineProperties[1], newCharacter);
                    }
                    else if (lineProperties[0] == "TRANSPORT" && !allTransports.ContainsKey(Convert.ToInt32(lineProperties[2])))
                    {
                        testRoom = allRooms[lineProperties[3]];
                        Room Veninder = allRooms[lineProperties[1]];
                        Veninder.setTransport(lineProperties[2], testRoom);
                        allTransports.Add(Convert.ToInt32(lineProperties[2]), line);
                    }
                    else if (lineProperties[0] == "EXIT")
                    {
                        Room exitRoom = allRooms[lineProperties[3]];
                        Room currentRoom = allRooms[lineProperties[1]];
                        if (!(currentRoom.exits).ContainsKey(lineProperties[2])) 
                        {
                            (allRooms[lineProperties[1]]).setExit(lineProperties[2], exitRoom);                       
                        }
                        
                    }
                    else if (lineProperties[0] == "INVENTORY") 
                    {
                        (currentPerson.getInventory()).Add(lineProperties[2]);
                        testRoom = allRooms[lineProperties[1]];
                        testRoom.deleteItem(lineProperties[2]);
                    }
                }

                // Ændrer access eller om personen har svaret.
                reader.BaseStream.Position = 0;
                while (!reader.EndOfStream)
                {
                    string room = reader.ReadLine();
                    Room testRoom;
                    Character testCharacter;
                    string[] lineProperties = room.Split('#');
                    if (lineProperties[0] == "ROOM" && lineProperties[3] == "True" && allRooms.ContainsKey(lineProperties[2]))
                    {
                        testRoom = allRooms[lineProperties[2]];
                        testRoom.changeAccess();
                    }
                    else if (lineProperties[0] == "CHARACTER" && lineProperties[4] == "True" && allCharacters.ContainsKey(lineProperties[1]))
                    {
                        testCharacter = allCharacters[lineProperties[1]];
                        testCharacter.haveYouAnswered = true;
                    }
                }
            }
        }

        /// <summary>
        /// Henter alle gemte spil i en streng 
        /// </summary>
        /// <returns></returns>
        public string getSavedGames()
        {
            string savedGames = "";

            using (StreamReader streamReader = new StreamReader(@"..\..\Properties\SavedGames.txt"))
            {
                while (!streamReader.EndOfStream)
                {
                    
                    string firstSave = streamReader.ReadLine();
                    string[] saveProperties = firstSave.Split('#');
                    if(saveProperties[0] == "SAVE") 
                    savedGames = savedGames + " " + saveProperties[1] +"-"+ saveProperties[2] +",";
                }
            }
            return savedGames;
        }


        /// <summary>
        /// Printer den nuværende highscore liste - let hvis du spiller let og svær hvis du spiller svær.
        /// </summary>
        /// <param name="difficulty"></param>
        public void printScore(string difficulty)
        {
            List<Score> highscores = new List<Score>();
            Score testScore;
            string pathToRead = "";
            string stringToPrint = "";

            if (difficulty == "Let") 
            {
                pathToRead = @"..\..\Properties\HighscoresLet.txt";
            }
            else if (difficulty == "Svær")
            {
                pathToRead = @"..\..\Properties\HighscoresSvær.txt";
            }
            
            using (StreamReader reader = new StreamReader(pathToRead))
            {
                while (!reader.EndOfStream)
                {
                    string score = reader.ReadLine();
                    string[] scoreProperties = score.Split('#');
                    highscores.Add(new Score(scoreProperties[1], Convert.ToInt32(scoreProperties[0])));
                }
            }
            
            if (highscores.Count == 0)
                return;

            Console.WriteLine("Highscores: " + difficulty);
            highscores.Sort();
            highscores.Reverse();

            for (int i = 0; i < highscores.Count; i++)
            {
                testScore = highscores[i];
                stringToPrint = Convert.ToString(testScore.score) + "-" + testScore.scoreName;
                Console.WriteLine(i + 1 + ". " + stringToPrint);
            }
        }
    }
}
