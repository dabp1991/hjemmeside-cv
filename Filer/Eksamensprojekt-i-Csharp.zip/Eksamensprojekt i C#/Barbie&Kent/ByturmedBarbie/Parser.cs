﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BarbieAndKent
{

    /// <summary>
    /// Denne klasse er en del af "Barbie & Kent" applikationen.
    /// "Barbie & Kent" er et simpelt tekstbaseret adventurespil.  
    /// 
    /// Parseren læser bruger inputs og prøver at fortolke den en "Adventure" kommando.
    /// Hver gang den kaldes læser den en linje fra terminalen, og prøver at fortolke linjen som en kommando med to ord.
    /// Den returnerer kommandoen som en instans af kommando klassen.
    ///
    /// Parseren tjekker inputtet mod dens liste af alle kommando ordene. 
    /// Hvis input ikke stemmer overens med noget i listen, returneres det som ukendt.
    /// </summary>
    public class Parser
    {
        private CommandWords commands;  // Indeholder godkendte kommandoer
        private TextReader reader;         // source of command input


        /** Konstruktør **/
        /// <summary>Skaber en parser der læser fra terminalen.</summary>
        public Parser()
        {
            commands = new CommandWords();
            reader = Console.In;
        }

        /** Metode **/
        /// <returns> Den næste kommando fra brugeren </returns>
        public Command getCommand()
        {
            string inputLine;   // Indeholder hele inputtet
            string[] words;
            string word1 = null;
            string word2 = null;

            Console.Write("> ");     // printer prompt

            inputLine = reader.ReadLine();
            words = inputLine.Split(' ');

            word1 = (words.Length > 0 ? words[0] : null);
            word2 = (words.Length > 1 ? words[1] : null);

            // Her tjekkes det om ordet er kendt. Hvis det er, skabes en kommando med den.
            // Hvis ikke, skabes en null kommando.
            if (commands.isCommand(word1))
            {
                return new Command(word1, word2);
            }
            else
            {
                return new Command(null, word2);
            }
        }

        //
        public Command getInput()
        {
            string inputLine;   // Indeholder hele inputtet
            string[] words;
            string word1 = null;
            string word2 = null;

            Console.Write("> ");     // printer prompt

            inputLine = reader.ReadLine();
            words = inputLine.Split(' ');

            word1 = (words.Length > 0 ? words[0] : null);
            word2 = (words.Length > 1 ? words[1] : null);
            return new Command(word1, word2);
        }

        /// <summary>Printer en liste af godkendte inputs.</summary>
        public void showCommands()
        {
            commands.showAll();
        }
    }
}
