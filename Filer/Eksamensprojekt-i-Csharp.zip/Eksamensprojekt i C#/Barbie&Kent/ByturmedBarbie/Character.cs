﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace BarbieAndKent
{
    public class Character
    {
        ///  Denne klasse er en del af "Barbie & Kent" applikationen.
        /// "Barbie & Kent" er et simpelt tekstbaseret adventurespil. 

        //Properties
        public Room CurrentPlace {get; private set;}
        public string Name{get; private set;}
        public string Answer{get; private set;}
        public string questionToAsk { get; private set; }
        private bool haveYouAsked = false;
        public bool haveYouAnswered = false;
        private Question currentQuestion;
        public List<Question> allQuestions = new List<Question>();

        //Konstruktoer for klassen
        public Character(Room place, string name, string text)
        {
            this.CurrentPlace = place;
            this.Name = name;
            this.Answer = text;
        }

        public void moveCharacter()
        {
            //Laver en lokal liste med alle mulige udgange i det nuværende rum.
            List<string> exitList = new List<string>();
            exitList = CurrentPlace.getExitList();

            //Finder en tilfældig udgang som han skal tage
            Random exit = new Random();
            int randomExit = exit.Next(0, exitList.Count);
            string nextExit = exitList[randomExit];

            // Try to leave current room.
            Room nextRoom = CurrentPlace.getExit(nextExit);

            //Tjekker at doeren han proever at gå ind af en låst doer. 
            if (nextRoom.getAccess() == false)
            {
                return;
            }


            //Ændrer hans placering hvis han rammer et rum han kan gå ind i.
            Character randomDude = new Character(CurrentPlace, Name, Answer);
            CurrentPlace.deleteCharacter(Name);
            CurrentPlace = nextRoom;
            CurrentPlace.setCharacter(randomDude);

        }

        /// <summary>
        /// Tjekker om characteren er i det samme rum som barbie, i det at barbie går ind i rummet.
        /// </summary>
        /// <param name="barbieRoom"></param>
        /// <returns>Returnerer falsk hvis ikke de er i samme rum, ellers returnerer den true</returns>
        /*public bool isCharacterInRoom(Room barbieRoom)
        {
            if (barbieRoom == CurrentPlace)
            {
                Console.WriteLine("\n"+Name+" is in this room");
                return true;
            }
            return false;
        }*/

        public string getRandomQuestion()
        {
            // Returnerer det foerste spoergsmål man har stillet, hvis man allerede har stillet et spoergsmål
            if (haveYouAsked == true) 
            {
                return questionToAsk;
            }

            //Finder en tilfældig udgang som han skal tage
            Random randomQuestion = new Random();
            int questionIndex = randomQuestion.Next(0, allQuestions.Count);
            Question questionClass = allQuestions[questionIndex];
            string nextQuestion = questionClass.oneQuestion;
            
            haveYouAsked = true;
            questionToAsk = nextQuestion;
            currentQuestion = questionClass;

            return nextQuestion;
        }

        /// <summary>
        /// Skaber alle spoergsmål for denne karakter
        /// </summary>
        /// <param name="character"></param>
        public void setQuestion(string question, string answer)
        {
            Question newQuestion; 
            newQuestion = new Question(question, answer); 
            allQuestions.Add(newQuestion);
        }


        //Returnerer et svar
        public string getAnswer(string AskedQuestion)
        {

            int i = 0;
            while (i < allQuestions.Count)
            {
                Question testQuestion = allQuestions[i];
                if (AskedQuestion == testQuestion.oneQuestion && testQuestion.Answer == currentQuestion.Answer)
                {
                    haveYouAnswered = true;
                    return testQuestion.Answer;
                }
                else i++;
            }
            haveYouAnswered = true;
            return null;
        }

    }
}
