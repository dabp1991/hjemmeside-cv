﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BarbieAndKent
{
    public class Question
    {
        string question {get; set;}
        string answer {get; set;}
        Room place { get; set; }
        List<Question> allQuestions = new List<Question>();

        public Question()
        {
           
        }

        public void setQuestion()
        {

        }

        public void GetRandomQuestion();
    }
}
