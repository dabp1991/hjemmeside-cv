﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;

namespace BarbieAndKent
{
    public class Item
    {
        ///  Denne klasse er en del af "Barbie & Kent" applikationen.
        /// "Barbie & Kent" er et simpelt tekstbaseret adventurespil. 

        /*Definerer lokale variabler til klassen*/

        public string Place {get; set;}
       public string Name {get;set;}
       public bool Take{get;set;}
       public int Weight { get; set; }

        /*Konstruktoer*/

        /// <summary>
        /// 
        /// </summary>
        /// <param name="place"></param>
        /// <param name="name"></param>
        /// <param name="take"></param>
        /// <param name="wieght"></param>
        public Item(string place, string name, bool take, int weight)
        {
            this.Place = place;
            this.Name = name;
            this.Take = take;
            this.Weight = weight;
        }      
        
        }

    }

