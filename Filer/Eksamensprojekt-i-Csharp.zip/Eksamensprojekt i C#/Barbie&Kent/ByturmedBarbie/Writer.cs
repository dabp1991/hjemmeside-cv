﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;

namespace BarbieAndKent
{
    /// <summary>
    ///  Denne klasse er en del af "Barbie & Kent" applikationen.
    /// "Barbie & Kent" er et simpelt tekstbaseret adventurespil. 
    /// 
    /// Klassen Writer har metoder til at gemme alle de forskellige properties fra det spil man spiller lige nu i en tekstfil, sådan at det efterfølgende kan gemmes og hentes.
    /// </summary>

    public class Writer
    {
        string currentGame = @"..\..\Properties\CurrentGame.txt";

        /// <summary>
        /// 
        /// </summary>
        /// <param name="currentRoom"></param>
        public void writeCurrentRoom(Room currentRoom)
        {
            string roomToAdd = "";
            string roomToOverWrite = "";
            bool startGame = true;

            using (StreamReader reader = new StreamReader(currentGame))
            {

                while (!reader.EndOfStream)
                {
                    string room = reader.ReadLine();
                    string[] roomProperties = room.Split('#');
                    if (roomProperties[0] == "ROOM" && currentRoom.getRoomName() == roomProperties[2])
                    {
                        roomToAdd = "\n"+"CURRENTROOM" + "#" + roomProperties[1] + "#" + roomProperties[2] + "#" + roomProperties[3] + "#";
                    }
                    else if (roomProperties[0] == "CURRENTROOM")
                    {
                        roomToOverWrite = room;
                        startGame = false;
                    }
                }
            }

            //Skriver en ny linie med currentRoom hvis den ikke er tilføjet.
            using (StreamWriter writer = File.AppendText(currentGame))
            {
                if (startGame == true)
                {
                    writer.WriteLine();
                    writer.WriteLine(roomToAdd);
                    return;
                }
            }
            //
            string allText = File.ReadAllText(currentGame);
            allText = allText.Replace(roomToOverWrite, roomToAdd);
            File.WriteAllText(currentGame, allText);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="newItem"></param>
        public void takeItem(Item newItem)
        {
            string itemToDelete;
            using (StreamWriter writer = File.AppendText(currentGame))
            {
                itemToDelete = "ITEM#" + newItem.Place + "#" + newItem.Name + "#" + newItem.Take + "#" + newItem.Weight;
                string itemToAdd = "INVENTORY#" + newItem.Place + "#" + newItem.Name + "#" + newItem.Take + "#" + newItem.Weight;
                writer.WriteLine(itemToAdd);
            }

            string allText = "";

            //Finder linien hvor Item har været på og sletter den.
            using (StreamReader reader = new StreamReader(currentGame))
            {
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    if (line != itemToDelete)
                    {
                        allText = allText + line + "\n";
                    }

                }
            }
            File.WriteAllText(currentGame, allText);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="currentperson"></param>
        /// <param name="weighttoadd"></param>
        public void setTheWeight(Person currentPerson, int weighttoadd)
        {
            string allText = "";

            using (StreamReader reader = new StreamReader(currentGame))
            {
                string weightstring = Convert.ToString(currentPerson.myWeight + weighttoadd);

                while (!reader.EndOfStream)
                {
                    string person = reader.ReadLine();
                    string[] personProperties = person.Split('#');
                    if (personProperties[0] == "PERSON")
                    {
                        allText = allText + "PERSON#" + weightstring + "#" + currentPerson.scoreName + "#" + currentPerson.currentScore + "\n";

                    }
                    else allText = allText + person + "\n";
                }
            }
            File.WriteAllText(currentGame, allText);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="nextRoom"></param>
        public void changeAccess(Room nextRoom)
        {
            string allText = "";

            //Finder linien hvor Item har været på og sletter den.
            using (StreamReader reader = new StreamReader(currentGame))
            {
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    string[] lineProperties = line.Split('#');
                    if (lineProperties[0] == "ROOM" && lineProperties[2] == nextRoom.getRoomName())
                    {
                        allText = allText + "ROOM#" + lineProperties[1] + "#" + lineProperties[2] + "#" + "True" + "\n";
                    }
                    else allText = allText + line + "\n";

                }
            }
            File.WriteAllText(currentGame, allText);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="currentRoom"></param>
        public void questionAnswered(Room currentRoom)
        {
            string allText = "";

            // 
            using (StreamReader reader = new StreamReader(currentGame))
            {
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    string[] lineProperties = line.Split('#');
                    if (lineProperties[0] == "CHARACTER" && lineProperties[2] == currentRoom.getRoomName())
                    {
                        allText = allText + "CHARACTER#" + lineProperties[1] + "#" + lineProperties[2] + "#" + lineProperties[3] + "#" + "True" + "\n";
                    }
                    else allText = allText + line + "\n";

                }
            }
            File.WriteAllText(currentGame, allText);
        }

        /// <summary>
        /// Gemmer en person via et input af de forskellige attributter en person har. Bruges kun når spillet startes.
        /// </summary>
        /// <param name="name"></param>
        public void setPerson(string name, int boose, int hungry, string difficulty)
        {
            using (StreamWriter writer = File.AppendText(currentGame))
            {
                writer.WriteLine();
                string personToAdd = "PERSON#0#"+ name +"#" + "1000"+"#"+Convert.ToString(boose)+"#"+Convert.ToString(hungry)+"#"+difficulty;
                writer.WriteLine(personToAdd);

            }
        }
        /// <summary>
        /// Gemmer personen med en Person input.
        /// </summary>
        /// <param name="currentRoom"></param>
        public void setPerson(Person currentPerson)
        {
            string allText = "";

            // 
            using (StreamReader reader = new StreamReader(currentGame))
            {
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    string[] lineProperties = line.Split('#');
                    if (lineProperties[0] == "PERSON")
                    {
                        allText = allText + "PERSON#" + lineProperties[1] + "#";
                        allText = allText + lineProperties[2] + "#";
                        allText = allText + Convert.ToString(currentPerson.currentScore)+"#";
                        allText = allText + Convert.ToString(currentPerson.drunkness)+"#";
                        allText = allText + Convert.ToString(currentPerson.Mæthed) + "#";
                        allText = allText + currentPerson.difficulty;
                    }
                    else allText = allText + line + "\n";                       

                }
            }
            File.WriteAllText(currentGame, allText);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="currentPerson"></param>
        public void newScore(Person currentPerson)
        {
            string path = "";
            if (currentPerson.difficulty == "Svær")
                path = @"..\..\Properties\HighscoresSvær.txt";
            else path = @"..\..\Properties\HighscoresLet.txt";

            using (StreamWriter writer = File.AppendText(path))
            {
                string scoreToAdd = currentPerson.currentScore + "#" + currentPerson.scoreName;
                writer.WriteLine(scoreToAdd);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="characterToDelete"></param>
        public void deleteCharacter(Character characterToDelete)
        {
            string allText = "";
            using (StreamReader reader = new StreamReader(currentGame))
            {
                
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    string[] characterProperties = line.Split('#');
                    if (characterProperties[0] == "CHARACTER" && characterToDelete.Name == characterProperties[1])
                    {
                     //Gør intet   
                    }                   
                    else allText = allText + line + "\n";

                    
                }
            }
            File.WriteAllText(currentGame, allText);
        }

        /// <summary>
        /// overskriver en save path hvem man gemmer et spil med samme navn og forskellige sværhedsgrad oven på hinanden.
        /// </summary>
        /// <param name="characterToDelete"></param>
        public void overwriteSave(string saveName, Person currentPerson)
        {
            string allText = "";
            string pathToOverwrite = @"..\..\Properties\SavedGames.txt";
            using (StreamReader reader = new StreamReader(pathToOverwrite))
            {

                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    string[] lineProperties = line.Split('#');
                    if (lineProperties[0] == "SAVE" &&  saveName == lineProperties[1])
                    {
                        allText = allText+lineProperties[0]+"#"+lineProperties[1]+"#"+currentPerson.difficulty;
                    }
                    else allText = allText + line + "\n";


                }
            }
            File.WriteAllText(pathToOverwrite, allText);
        }
        
    }
}
