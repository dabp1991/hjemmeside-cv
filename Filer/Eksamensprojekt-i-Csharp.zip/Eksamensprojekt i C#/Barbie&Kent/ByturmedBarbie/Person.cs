﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;

namespace BarbieAndKent
{
    ///  Denne klasse er en del af "Barbie & Kent" applikationen.
    /// "Barbie & Kent" er et simpelt tekstbaseret adventurespil. 

    public class Person
    {

        public string scoreName { get; set; }
        public int currentScore { get; set; }
        public int drunkness { get; set; }
        public int Mæthed { get; set; }
        public string difficulty { get; set; }
        private List<string> myInventory = new List<string>();
        public int myWeight { get; set; }

        public Person(int weight, int drunk, int sult)
        {
            this.myWeight = weight;
            this.drunkness = drunk;
            this.Mæthed = sult;
        }

        public void addItem(string newItem)
        {
            myInventory.Add(newItem);
        }

        public List<string> getInventory()
        {
            return myInventory; 
        }

    }
}
