﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;

namespace BarbieAndKent
{
    ///  Denne klasse er en del af "Barbie & Kent" applikationen.
    /// "Barbie & Kent" er et simpelt tekstbaseret adventurespil. 

    class Program
    {
        static void Main(string[] args)
        {
            //Laver et game object og starter spillet.
            Game newGame = new Game();
            newGame.play();
        }
    }
}
