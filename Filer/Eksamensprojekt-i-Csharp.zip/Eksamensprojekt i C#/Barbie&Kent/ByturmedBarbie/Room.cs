﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;

namespace BarbieAndKent
{
    /// <summary>
    /// Definerer et rum i spillet.
    /// 
    ///  Denne klasse er en del af "Barbie & Kent" applikationen.
    /// "Barbie & Kent" er et simpelt tekstbaseret adventurespil. 
    /// 
    /// </summary>
    public class Room
    {
        /** Fields **/
        public Dictionary<string, Room> exits;        // Gemmer udgange for det her rum
        private Dictionary<string, Room> transports;    // Gemmer transporter udgange.
        private string Name;
        private bool Access;
        private string accessstring;
        List<Item> itemsInRoom = new List<Item>();
        Dictionary<string, Character> charactersInRoom = new Dictionary<string, Character>();

        /** Properties **/
        /// <summary>Den korte beskrivelse af rummet</summary>
        public string Description { get; set; }

        /** Konstruktører **/
        /// <summary>
        /// Skaber et rum og beskriver adgang og beskrivelse af det.
        /// </summary>
        /// <param name="description">The room's description.</param>
        public Room(string description, string name, bool access)
        {
            this.Description = description;
            this.Name = name;
            this.Access = access;
            exits = new Dictionary<String, Room>();
            transports = new Dictionary<String, Room>();

        }

        /** Metoder **/
        /// <summary>
        /// Definerer udgange for rummet
        /// </summary>
        /// <param name="direction">Definerer hvilke vej udgangen er.</param>
        /// <param name="neighbor">Definerer rummet hvor udgangen går hen til</param>
        public void setExit(string direction, Room neighbor)
        {
            exits.Add(direction, neighbor);
        }

        /// <summary>Returnerer en beskrivelse af rummet:
        /// </summary>
        /// <returns>En lang beskrivelse af rummet</returns>
        public String getLongDescription()
        {
            string itemString="";
            if (getCharacterString() != "" || getItemString() != "")
                itemString = "Ved " + getRoomName() + " er der "+getItemString();
            return Description + "\n" + itemString + getCharacterString() +"\n"+getExitString()+".";
        }

        public String getDescription()
        {
            Console.WriteLine();
            return Description + ".\n";
        }

        /// <summary>Returnerer en streng der beskriver mulige udgange fra rummet.
        /// </summary>
        /// <returns>Detaljer i rummets udgange.</returns>
        public String getExitString()
        {
            String returnString = "Exits:";
            ICollection<string> keys = exits.Keys;
            foreach (string exit in keys)
            {
                returnString += " " + exit;
            }
            return returnString;
        }

        /// <summary>Returnerer rummet i en given retning
        /// </summary>
        /// <param name="direction">Vejen til udgangen</param>
        /// <returns>Rummet i en given retning</returns>
        public Room getExit(string direction)
        {
            if (exits.ContainsKey(direction))
                return exits[direction];
            else
                return null;
        }

        public List<string> getExitList()
        {
            return exits.Keys.ToList();
        }

        /// <summary>
        /// Metode til at skabe transportrum.
        /// </summary>
        /// <param name="direction"></param>
        /// <param name="neighbor"></param>
        public void setTransport(string direction, Room neighbor)
        {
            transports.Add(direction, neighbor);
        }

        /// <summary>
        /// Henter transport rum
        /// </summary>
        /// <param name="direction"></param>
        /// <returns></returns>
        public Room getTransport(string direction)
        {
            if (transports.ContainsKey(direction))
                return transports[direction];
            else
                return null;
        }

        //Henter rummets navn

        public string getRoomName()
        {
            return Name;
        }

        /*Methoder for room adgang*/
        //Sets the string for access

        public string setAccessText(string access)
        {
            this.accessstring = access;
            return access;
        }

        //Henter access tekst

        public string getAccessText()
        {
            return accessstring;
        }

        //Henter accessvaerdi

        public bool getAccess()
        {
            return Access;
        }

        public void changeAccess()
        {
            Access = true;
        }

        /*Methoder til items*/
        /// <summary>
        /// Metoder til at tilfoeje, fjerne, og hente items i rummene.
        /// </summary>

        public void setItem(Item newItem)
        {
            itemsInRoom.Add(newItem);
        }

        /*Henter en af de items der er i rummet.
          Bliver brugt til at samle en af de items der er i rummet op*/
        public Item getOneItem(string command)
        {
            int i = 0;
            Item returnItem = null;
            Item testItem = null;
            while (i < itemsInRoom.Count)
            {
                testItem = itemsInRoom[i];
                i = i + 1;
                if (testItem.Name == command)
                {
                    returnItem = testItem;
                    return testItem;
                }
            }
            return returnItem;
        }

        /*Sletter en af de items der er i rummet.
          Bliver brugt til at slette items som bliver samlet op af Barbie*/
        public void deleteItem(string name)
        {
            for (int i = 0; i < itemsInRoom.Count; i++)
            {
                if (itemsInRoom[i].Name == name)
                {
                    itemsInRoom.RemoveAt(i);
                }
            }
        }

        /// <summary>
        /// Returnerer en streng med de forskellige items der er i rummet.
        /// Hvis der ikke er nogle items returnerer den null.
        /// Derefter koerer der en loekke, der gemmer alle items i rummet i en streng.
        /// </summary>
        /// <returns></returns>


        public string getItemString()
        {
            int i = 0;
            string allNamesTest = "";
            if (itemsInRoom.Count == 0)
            {
                return "";
            }

            while (i < itemsInRoom.Count)
            {
                Item testItem = itemsInRoom[i];
                allNamesTest = allNamesTest + ": " + (testItem.Name) + ",";
                i = i + 1;
            }
            string itemDescription = "";
            Console.WriteLine();
            return itemDescription + allNamesTest;
        }
        
        /// <summary>
        /// Character metoder
        /// </summary>
        /// <param name="newCharacter"></param>
        public void setCharacter(Character newCharacter)
        {
            charactersInRoom.Add(newCharacter.Name, newCharacter);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="characterToDelete"></param>
        public void deleteCharacter(string characterToDelete)
        {
            charactersInRoom.Remove(characterToDelete);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Dictionary<string, Character> getCharacters() 
        {
            return charactersInRoom;
        }

        /// <summary>
        /// Returnerer en streng med linieskift og karakterens navn.
        /// </summary>
        private string getCharacterString()
        {
            string returnstring = "";
            if (charactersInRoom.Count == 0)
                return "";
            foreach (string key in charactersInRoom.Keys)
            {
                if (key == "GymnasieElever")
                    returnstring = returnstring + " en flok " + key+",";
                else returnstring = returnstring + " " + key+", ";
            }
           return returnstring+"\n";
        }

    }
}