﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;

namespace BarbieAndKent
{
    /// <summary>
    /// Denne klasse indeholder en enum med alle command ordene i spillet.
    /// Den bruges til at godkende kommando når den bliver skrevet ind. 
    /// </summary>
    public class CommandWords
    {
        /// <summary>
        /// Et enum der indeholder alle de godkendte kommandoer
        /// </summary>
        private enum ValidCommands
        {
            hjælp,
            gå,
            quit,
            tilbage,
            minvægt,
            tag,
            inventar,
            spørg,
            svar,            
            gem,
            indlæs,
        }

        /** Konstruktører **/
        /// <summary>
        /// Konstruktør - initialiserer CommandWords klassen.
        /// </summary>
        public CommandWords()
        {
            // Gør ikke så meget mere.
        }

        /** Metoder **/
        /// <summary>
        /// Tjekker om den givne streng er en kommando. 
        /// </summary>
        /// <returns>Sandt hvis den er, falsk hvis den ikke er</returns>
        public bool isCommand(string aString)
        {
            return Enum.IsDefined(typeof(ValidCommands), aString);
        }

        /// <summary>
        /// Printer alle godkendte kommandoer ud.
        /// </summary>
        public void showAll()
        {
            foreach (ValidCommands command in Enum.GetValues(typeof(ValidCommands)))
            {
                Console.Write(command.ToString() + "  ");
            }
            Console.WriteLine();
        }
    }
}
