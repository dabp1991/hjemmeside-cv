﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;

namespace BarbieAndKent
{
    ///  Denne klasse er en del af "Barbie & Kent" applikationen.
    /// "Barbie & Kent" er et simpelt tekstbaseret adventurespil. 

    public class Question
    {
        public string oneQuestion { get;  set; }
        public string Answer { get; set; }

        public Question(string question, string answer)
        {
            oneQuestion = question;
            Answer = answer;
        }

    }
}
