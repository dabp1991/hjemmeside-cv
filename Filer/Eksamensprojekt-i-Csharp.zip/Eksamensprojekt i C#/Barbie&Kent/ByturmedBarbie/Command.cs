﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;

namespace BarbieAndKent
{
    /// <summary>
    ///  Denne klasse er en del af "Barbie & Kent" applikationen.
    /// "Barbie & Kent" er et simpelt tekstbaseret adventurespil.
    /// 
    /// Denne klasse holder informationer omkring de kommandoer som spilleren bruger.
    /// En kommando består af to strenge.
    /// 
    /// </summary>
    public class Command
    {
        /** Properties **/
        /// <summary>
        /// Returnerer det første kommandoord i kommandoen. Hvis kommandoen ikke er forstået er resultatet null.
        /// </summary>
        public string CommandWord { get; private set; }

        /// <summary> Returnerer det andet kommandoord i kommandoen. Hvis kommandoen ikke er forstået er resultatet null. </summary>
        public string SecondWord { get; private set; }


        /** Konstruktører **/
        /// <summary>
        /// Laver et kommandoobjekt med første og andet ord.
        /// </summary>
        /// <param name="firstWord">Det første ord i kommandoen</param> 
        /// <param name="secondWord">Det andet ord i kommandoen</param>                 
        public Command(string firstWord, string secondWord)
        {
            CommandWord = firstWord;
            this.SecondWord = secondWord;
        }

        /** Metoder **/
        /// <returns> true hvis kommandoen er forstået </returns>
        public bool isUnknown()
        {
            return (CommandWord == null);
        }

        /// <returns> true hvis kommandoen har et andet ord </returns>
        public bool hasSecondWord()
        {
            return (SecondWord != null);
        }
    }
}
