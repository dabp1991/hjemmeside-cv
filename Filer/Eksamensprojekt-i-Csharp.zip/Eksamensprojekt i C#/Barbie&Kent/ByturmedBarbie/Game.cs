﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;

namespace BarbieAndKent
{
    /// <summary>
    /// Denne klasse er en del af "Barbie & Kent" applikationen.
    /// "Barbie & Kent" er et simpelt tekstbaseret adventurespil.
    /// Spillere kan gå rundt, tage ting op, spørge andre karakterere og svare på gåder.
    /// 
    /// Denne klasse er hovedklassen for spillet hvor hele spillet går ud fra.
    /// Rum, spillere, parser, items karakterer osv. bliver skabt i denne her klasse.
    /// Den evaluerer også og udfører de kommandoer som parseren returnerer 
    /// 
    /// For at spille spillet bliver skabt ved at lave en instans af game klassen hvorefter 'play' metoden kaldes.
    /// Dette sker i 'Program' klassen, der også er main klasse for spillet. 
    /// </summary>
    public class Game
    {
        //Alle atributterne til de forskellige klasser 
        private Parser parser;
        private Writer textWriter;
        private Reader textReader;
        private Room currentRoom;
        private Character randomDude;
        private Character characterToAsk;
        private Room lastRoom;
        private String currentQuestion;
        private Person currentPerson;
        private Dictionary<string, Room> allRooms;
        private Dictionary<string, Character> currentRoomCharacters;
        private Dictionary<string, Character> allCharacters;
        private Dictionary<int, string> allTransports;
       
        
        /** Konstruktører **/
        /// <summary>Starter spillet og initialiserer et internt kort.</summary>
        public Game()
        {
            textWriter = new Writer();
            textReader = new Reader();
            parser = new Parser();
            currentPerson = new Person(0, 0, 100);
            allRooms = new Dictionary<string, Room>();
            allCharacters = new Dictionary<string, Character>();
            allTransports = new Dictionary<int, string>();
            setGame();
            createGame();
        }

        /** Metoder **/
        /// <summary>Skaber alting i koden</summary>            

        private void setGame()
        {
            bool finished = false;
            string difficulty ="";
            string currentGamePath = @"..\..\Properties\CurrentGame.txt";

            Console.WriteLine("Velkommen til Barbie i Byen");
            Console.WriteLine("Før spillet begynder skal du vælge en sværhedsgrad");
            Console.WriteLine("Vil du spille - let eller svær?");
            while (!finished)
            {
                Command command = parser.getInput();
                

                if (command.CommandWord == "let" || command.CommandWord == "Let")
                {

                    string settingPath = @"..\..\Properties\LetSettings.txt";
                    finished = true;
                    Console.WriteLine();
                    System.IO.File.Copy(settingPath, currentGamePath, true);
                    difficulty = "Let";
                }
                else if (command.CommandWord == "svær" || command.CommandWord == "Svær")
                {

                    string settingPath = @"..\..\Properties\SværSettings.txt";
                    finished = true;
                    Console.WriteLine();
                    System.IO.File.Copy(settingPath, currentGamePath, true);
                    difficulty = "Svær";
                }
                else Console.WriteLine("Du skal vælge en af de tre sværhedsgrader");
            }
            
            Console.WriteLine("Du skal nu skrive et navn til din spiller");
            finished = false;
            while (!finished)
            {
                Command command = parser.getInput();

                if (command.CommandWord != null && command.CommandWord != "")
                {
                    finished = true;
                    string name = command.CommandWord;
                    Console.WriteLine();
                    textWriter.setPerson(name, 0, 100, difficulty);
                    currentPerson.currentScore = 1000;
                    currentPerson.scoreName = name;
                    currentPerson.difficulty = difficulty;
                }
                else Console.WriteLine("Du skal skrive et navn");
            }
        }

        /// <summary>
        /// Laver spillet efter den setting vi har valgt.
        /// </summary>
        private void createGame() 
        {
            string readPath = "";
            if (currentPerson.difficulty == "Let")
                readPath = @"..\..\Properties\LetSettings.txt";
            else readPath = @"..\..\Properties\SværSettings.txt";

            using (StreamReader reader = new StreamReader(readPath))
            { 
                while (!reader.EndOfStream)
                {
                    Room roomToAdd;
                    string room = reader.ReadLine();
                    string[] roomProperties = room.Split('#');
                    string roomInfo = "";
                    if (roomProperties[0] == "ROOM")
                    {
                        room = roomProperties[2];
                        
                        // Metode til splitte deskriptionen op i flere dele i selve teksten.                       
                        string[] roomDescriptionSplit = roomProperties[1].Split('*');
                        for (int i = 0; roomDescriptionSplit.Length > i; i++)
                        {
                            roomInfo = roomInfo + "\n" + roomDescriptionSplit[i];                           
                        }
                       
                        roomToAdd = new Room(roomInfo, room, Convert.ToBoolean(roomProperties[3]));
                        allRooms.Add(room, roomToAdd);
                    }

                }

                //Skaber items og placerer dem i de forskellige rum.

                reader.BaseStream.Position = 0;
                while (!reader.EndOfStream)
                {
                    Item itemToAdd;
                    Room roomToPlaceItem;
                    string item = reader.ReadLine();
                    string[] itemProperties = item.Split('#');                   
                    if (itemProperties[0] == "ITEM")
                    {
                        item = itemProperties[2];
                        itemToAdd = new Item(itemProperties[1], item, Convert.ToBoolean(itemProperties[3]), Convert.ToInt32(itemProperties[4]));
                        roomToPlaceItem = allRooms[itemProperties[1]];
                        roomToPlaceItem.setItem(itemToAdd);
                    }

                }

                //Sætter Exits

                reader.BaseStream.Position = 0;
                while (!reader.EndOfStream)
                {
                    Room exitRoom;
                    string exit = reader.ReadLine();
                    string[] exitProperties = exit.Split('#');
                    if (exitProperties[0] == "EXIT")
                    {
                        exitRoom = allRooms[exitProperties[3]];
                        (allRooms[exitProperties[1]]).setExit(exitProperties[2], exitRoom);
                    }

                }

                //Sætter transports til transporterrummet
                reader.BaseStream.Position = 0;
                while (!reader.EndOfStream)
                {
                    Room exitRoom;
                    Room Veninder;
                    string transport = reader.ReadLine();
                    string[] transportProperties = transport.Split('#');
                    if (transportProperties[0] == "TRANSPORT")
                    {
                        exitRoom = allRooms[transportProperties[3]];
                        Veninder = allRooms[transportProperties[1]];
                        Veninder.setTransport(transportProperties[2], exitRoom);
                        allTransports.Add(Convert.ToInt32(transportProperties[2]), transport);
                    }

                }

                //Sætter karakterer
                reader.BaseStream.Position = 0;
                while (!reader.EndOfStream)
                {
                    Room characterRoom;
                    Character newCharacter;
                    string character = reader.ReadLine();
                    string[] characterProperties = character.Split('#');
                    if (characterProperties[0] == "CHARACTER")
                    {
                        characterRoom = allRooms[characterProperties[2]];
                        newCharacter = new Character(characterRoom, characterProperties[1], characterProperties[3]);
                        allCharacters.Add(characterProperties[1], newCharacter);
                        characterRoom.setCharacter(newCharacter);
                        if (characterProperties[1] == "RandomDude")
                        {
                            randomDude = newCharacter;
                        }
                        
                        
                    }

                }

                //Sætter spørgsmål

                reader.BaseStream.Position = 0;
                while (!reader.EndOfStream)
                {
                    Character newCharacter;
                    string question = reader.ReadLine();
                    string[] questionProperties = question.Split('#');
                    if (questionProperties[0] == "QUESTION" && allCharacters.ContainsKey(questionProperties[1]))
                    {
                        newCharacter = allCharacters[questionProperties[1]];
                        newCharacter.setQuestion(questionProperties[2], questionProperties[3]);
                    }

                }

                //Sætter adgangs tekst
                reader.BaseStream.Position = 0;
                while (!reader.EndOfStream)
                {
                    Room accessRoom;
                    string access = reader.ReadLine();
                    string[] accesTextProperties = access.Split('#');
                    if (accesTextProperties[0] == "ACCESSTEXT")
                    {
                        
                        // Metode til splitte deskriptionen op i flere dele i selve teksten. 
                        string accesstext = "";
                        string[] accessDescriptionSplit = accesTextProperties[2].Split('*');
                        for (int i = 0; accessDescriptionSplit.Length > i; i++)
                        {
                            accesstext = accesstext + "\n" + accessDescriptionSplit[i];
                        }
                        accessRoom = allRooms[accesTextProperties[1]];
                        accessRoom.setAccessText(accesstext);
                    }

                }

            }
            currentRoom = allRooms["Lilletorv"]; //Sætter start rummet
            lastRoom = currentRoom;
            currentRoomCharacters = currentRoom.getCharacters();
            textWriter.writeCurrentRoom(currentRoom);
        }


        /// <summary>Spillets primære metode, looper indtil at spillet stopper.</summary>
        public void play()
        {
            printWelcome();

            // Starter kommando loopet, hvor kommondoer gentagende gange bliver læst og 
            // udført indtil spillet det slutter.
            // Spillet kan stoppe på tre måder, man går ud af det, vinder eller taber.
            // If sætningen i bunden ender spillet.
                
            bool finished = false;            
            while (!finished)
            {
                Command command = parser.getCommand();
                finished = processCommand(command);
            }
            if (currentRoom.getRoomName() == "Castenskjold") 
            {

                Console.WriteLine();
                Console.WriteLine("Din score var: " + (Convert.ToString(currentPerson.currentScore)));
                Console.WriteLine();
                textWriter.newScore(currentPerson);
                textReader.printScore(currentPerson.difficulty);
                Console.WriteLine("Tryk på en tast for at forlade spillet:");
            }
            else Console.WriteLine("Tak fordi du spillede vores spil. Farvel. "+" \n "+" Press any key to exit:");
            Console.ReadKey(); 
        }

        /// <summary>Printer åbningsteksten for spillet</summary>
        private void printWelcome()
        {
            Console.WriteLine("Velkommen til byen Aarhus");
            Console.WriteLine("Barbie har længe haft verdens største crush på Aarhus’ flotteste fyr, Ken.");
            Console.WriteLine("Ken har det flotteste hår, det sødeste smil og den fedeste tøjstil. ");
            Console.WriteLine("Efter en ordentlig omgang facebookstalking \nhar Barbie fundet frem til at Ken skal i byen i aften."); 
            Console.WriteLine("Men Ken skal ikke hvilket som helst sted hen. \nHan skal på byens smarteste sted, Castenskiold. ");
            Console.WriteLine("Barbie ved at hvis hun bare får chancen for en dirtydance med Ken, \nså vil han være solgt. ");
            Console.WriteLine("Der er bare et problem. \nBarbie har karantæne fra Castenskiold \nefter hun brækkede sig i DJ’ens pladespillere sidste weekend.");
            Console.WriteLine("Barbie er derfor på en mission gennem Aarhus' natteliv \nfor at finde et falsk ID og en paryk,"); 
            Console.WriteLine("så hun kan snyde sig forbi de sure, hårde og ikke mindste onde dørmænd.");
            Console.WriteLine();
            textReader.printScore(currentPerson.difficulty);
            Console.WriteLine();
            Console.WriteLine("Skriv 'hjælp' hvis du har brug for hjælp.");
            Console.WriteLine();
            Console.WriteLine(currentRoom.getLongDescription());          
        }

        /// <summary>Modtageren kommondo og eksekverer den.</summary>
        /// <param name="command">Kommandoen der skal eksekveres</param>
        /// <returns>True hvis kommandoen slutter spillet, ellers er den falsk.</returns>
        private bool processCommand(Command command)
        {
            bool wantToQuit = false;

            if (command.isUnknown())
            {
                Console.WriteLine("Jeg forstår ikke hvad du mener....");
                return false;
            }

            string commandWord = command.CommandWord;
            if (commandWord == "hjælp")
            {
                printHelp();
            }
            else if (commandWord == "gå")
            {
                goRoom(command);
                if ((currentRoom.getRoomName()) == "Castenskjold")
                {
                    wantToQuit = true;
                }
            }
            else if (commandWord == "quit")
            {
                wantToQuit = quit(command);
            }
            else if (commandWord == "tilbage")
            {
                backRoom(command);
            }
            else if (commandWord == "minvægt")
            {
                myweight(command);
            }
            else if (commandWord == "tag")
            {
                take(command);
            }
            else if (commandWord == "inventar")
            {
                inventory(command);
            }
            else if (commandWord == "spørg")
            {
                ask(command);
            }
            else if (commandWord == "svar")
            {
                svar(command);
            }
            else if (commandWord == "gem")
            {
                save(command);
            }
            else if (commandWord == "indlæs")
            {
                load(command);
            }
            // Hvis kommandoen ikke genkender kommandoen.
            return wantToQuit;
        }

        /** Implemmenteringen af kommandoerne: **/

        /// <summary>
        /// Printer hjælpe informationerne ud.
        /// Her bliver en tekst printet ud samt en liste og kommando mulighederne
        /// </summary>
        private void printHelp()
        {
            Console.WriteLine("Barbie skal finde en måde hvorpå \nhun kan komme ind i Castenskjold for at score Kent");
            Console.WriteLine("Du kan bevæge dig rundt i byen ved hjælp af kommandoerne, \nspørge folk og samle ting op som du finder");
            Console.WriteLine();
            Console.WriteLine("Her er en liste over alle de mulige kommandoer:");
            parser.showCommands();
        }

        /// <summary>
        /// Prøver at gå i en bestemt retning, hvis man kan gå ind og der er åbent går man ind,
        /// ellers returnerer den en fejl besked.
        /// </summary>
        private void goRoom(Command command)
        {
            if (!command.hasSecondWord())
            {
                // Hvis der ikke er et andet ord, ved vi ikke hvor vi skal gå hen...
                Console.WriteLine("Hvorhen vil du gå?");
                return;
            }

            String direction = command.SecondWord;

            // Prøver at forlade rummet.
            Room nextRoom = currentRoom.getExit(direction);

            if (nextRoom == null)
            {
                Console.WriteLine("Der gider Barbie ikke gå hen!");
                return;
            }

            // Tjekker om rummet er Castenskjold, hvis det er, bliver det testet om man både har falsk ID og paryk. 
            else if (nextRoom.getRoomName() == "Castenskjold" && (currentPerson.getInventory()).Contains("Paryk") && (currentPerson.getInventory()).Contains("Falsk-ID"))
            {
                nextRoom.changeAccess();
                textWriter.changeAccess(nextRoom);
            }

            //Tjekker om rummet er lukket.
            if (nextRoom.getAccess() == false)
            {
                Console.WriteLine(nextRoom.getAccessText());
            }

            // Går til næste rum.
            else
            {      
                lastRoom = currentRoom;
                currentRoom = nextRoom;
                currentRoomCharacters = currentRoom.getCharacters();
                Console.WriteLine();

                // Sætter funktioner i gang hvis spillets sværhedsgrad er Svær
                if (currentPerson.difficulty == "Svær")
                {
                    //Sender RandomDude rundt.
                    randomDude.moveCharacter();

                    currentPerson.Mæthed = currentPerson.Mæthed - 10;
                    if (currentPerson.Mæthed == 0)
                    {
                        Console.WriteLine("!! Byturen har gjort Barbie sulten, og hun kan ikke fortsætte festen før at hun har fundet noget pizza");
                        Item itemToAdd = new Item("Pizzaria", "Pizza", true, 0);
                        Room roomToAdd = allRooms["Pizzaria"];
                        roomToAdd.setItem(itemToAdd);
                        roomToAdd.Description = roomToAdd.Description +"\n"+"Bestyren har et godt øje til Barbie og giver hende en gratis slice";
                    }
                    if (currentRoom.getRoomName() == "StoretorvToilet" && currentPerson.drunkness == 100)
                    {
                        Console.WriteLine("!! Barbie finder det offentlige toilet ved Storetorv, \n hun bruger det og får det efterfølgende bedre");
                        currentPerson.drunkness = 50;
                        currentPerson.currentScore = currentPerson.currentScore - 20;
                        Console.WriteLine(currentRoom.getExitString());
                        return;
                    }
                }

                //Tester om det er transporter rummet
                if (currentRoom.getRoomName() == "Veninder")
                {
                    Console.WriteLine(currentRoom.getDescription());
                    transport();
                    currentRoomCharacters = currentRoom.getCharacters();
                    if (currentRoom.getRoomName() == "A-bar" || currentRoom.getRoomName() == "Heidis")
                    {
                        Console.WriteLine("Barbie er kommet ind på " + currentRoom.getRoomName() + ".");
                        Console.WriteLine(currentRoom.getDescription());
                        currentRoom = allRooms["Lilletorv"];
                        lastRoom = currentRoom;
                        Console.WriteLine(currentRoom.getLongDescription());
                        currentPerson.currentScore = currentPerson.currentScore - 200;
                        return;
                    }
                    else if (currentRoom.getRoomName() == "Castenskjold") 
                    {
                        Console.WriteLine(currentRoom.getDescription());
                        return;
                    }
                }
                    //Henter deskriptionen.
                else Console.WriteLine(currentRoom.getLongDescription());
                currentPerson.currentScore = currentPerson.currentScore - 20;

                                
            }
        }

        /// <summary>
        /// Der var skrevet quit.
        /// </summary>
        /// <returns>True hvis man har skrevet quit, false hvis du har skrevet mere end det.</returns>
        private bool quit(Command command)
        {
            if (command.hasSecondWord())
            {
                Console.WriteLine("Hvad vil du forlade?");
                return false;
            }
            else
            {
                return true;  
            }
        }


        /// <summary>
        /// "Back" returnerer dig tilbage til det sidste rum du har været i.
        /// Hvis du er i det rum du startede i, kommer der en fejlbesked.
        /// </summary>
        /// <param name="command"> </param>
        private void backRoom(Command command)
            {
                if (currentRoom == lastRoom)
                {
                 Console.WriteLine("Der er ingen steder at gå tilbage til");
                }

                else currentRoom = lastRoom;
                Console.WriteLine(currentRoom.getLongDescription()); 
            }

        /// "myWeight" giver din nuværende vægt.
        private void myweight(Command command)
        {
            string myWeightString = ((currentPerson.myWeight)*10).ToString();
            if ((currentPerson.getInventory()).Contains("XL-Håndtaske"))
            {
                Console.WriteLine("Din nuværende vægt er " + myWeightString + "kg. " + "Du kan kun bære 30 kg");
            }
            else Console.WriteLine("Din nuværende vægt er "+myWeightString+"kg. "+"Du kan kun bære 10 kg");
        }
            

        ///"Take" makes you take a item in the current room.
        ///You can't take an item which is not located in the current room.
        ///If there is no second word, i doesn't have an item to take.  
         private void take(Command command)
            {
                Item testItem = currentRoom.getOneItem(command.SecondWord);

                if (!command.hasSecondWord())
                {
                    Console.WriteLine("Tag hvad?");
                    return;
                }
                else if (testItem == null) 
                {
                    // Hvis der er et andet ord, og den ikke kan tages, returneres denne fejlbesked.
                    Console.WriteLine("Det kan du ikke tage");                    
                }
                // Tester om man kan tage den givne item og tilføjer den derefter til dit inventory hvis din vægt ikke er for høj.
                else if ((testItem.Take) == true)
                {
                    if ((currentPerson.getInventory()).Contains("XL-Håndtaske") || currentPerson.myWeight < 1 || testItem.Weight == 0)
                    {
                        (currentPerson.getInventory()).Add(testItem.Name);
                        Console.WriteLine("Du har nu taget: " + testItem.Name);
                        currentRoom.deleteItem(testItem.Name);
                        textWriter.setTheWeight(currentPerson, testItem.Weight);
                        currentPerson.myWeight = currentPerson.myWeight + testItem.Weight;
                        textWriter.takeItem(testItem);
                        if (testItem.Name == "Pizza")
                            currentPerson.Mæthed = 1000;
                        else if (testItem.Name == "bjørnebryg" || testItem.Name == "slots")
                        {
                            currentPerson.drunkness = currentPerson.drunkness + 50;
                            Console.WriteLine("Barbie drikker øllen og er ved at blive ret fuld");
                            if (currentPerson.drunkness == 100)
                                Console.WriteLine("!!Barbie får det dårligt af alle de øl, og må finde et toilet");                       
                        }
                    }
                    else Console.WriteLine("Barbie kan ikke bære så mange ting. \n Derfor bliver hun nød til at finde en større håndtaske før at hun kan tage mere" );
                }
                else Console.WriteLine("Det kan du ikke tage");
            }

        ///"Inventory" viser dig inventaret i din taske.
        ///
           private void inventory(Command command)
           {
                 Console.WriteLine("Barbie har en lækker håndtaske, og i den har hun:");
                 for (int i = 0; i < (currentPerson.getInventory()).Count; i++)
                 {
                     Console.WriteLine(i + 1 + ". " + (currentPerson.getInventory())[i]);
                 }
           }

        /// <summary>
        /// Spørger personen i rummet om en gåde hvortil der returneres et spørgsmål.
        /// </summary>
        /// <param name="command"></param>
           private void ask(Command command)
           {
                
               if (!command.hasSecondWord() || currentRoomCharacters == null || !currentRoomCharacters.ContainsKey(command.SecondWord))
               {
                   Console.WriteLine("Spørg hvem?");
                   return;
               }

               string secondWord = command.SecondWord;
               characterToAsk = currentRoomCharacters[secondWord];
               if (characterToAsk.haveYouAnswered == true)
               {
                   Console.WriteLine("Du har allerede svaret på et spørgsmål, og dørmanden gider ikke bruge mere tid på dig");
                   return;
               }            
               else if (currentPerson.difficulty == "Svær" && characterToAsk.Name == command.SecondWord && (characterToAsk.Name == "Fuldmand" || characterToAsk.Name == "GymnasieElever" || characterToAsk.Name == "RandomDude"))
               {
                   if (command.SecondWord == randomDude.Name && randomDude.CurrentPlace == currentRoom)
                   {
                       Console.WriteLine(randomDude.Answer);
                       currentPerson.drunkness = 150;
                       currentPerson.Mæthed = 1000;
                   }
                   else if (currentRoom.getRoomName() == "Åen")
                   {
                       string roomToPlace = currentRoom.getRoomName();
                       Item dåseØl = new Item(roomToPlace, "slots", true, 0);
                       currentRoom.setItem(dåseØl);
                       Console.WriteLine(currentRoomCharacters[command.SecondWord].Answer);
                       textWriter.deleteCharacter(characterToAsk);
                       (currentRoom.getCharacters()).Remove(command.SecondWord);
                       currentRoomCharacters.Remove(command.SecondWord);
                   }
                   else if (currentRoom.getRoomName() == "Klostergade")
                   {
                       string roomToPlace = currentRoom.getRoomName();
                       Item bjørnebryg = new Item(roomToPlace, "bjørnebryg", true, 0);
                       currentRoom.setItem(bjørnebryg);
                       Console.WriteLine(characterToAsk.Answer);
                       textWriter.deleteCharacter(characterToAsk);
                       (currentRoom.getCharacters()).Remove(command.SecondWord);
                       currentRoomCharacters.Remove(command.SecondWord);
                   }
               }
               else if (command.SecondWord == characterToAsk.Name)
               {
                   currentQuestion = characterToAsk.getRandomQuestion();
                   Console.WriteLine(currentQuestion);
               }
               else Console.WriteLine("Den person eksisterer ikke i rummet"); 

           }

        /// <summary>
        /// Spørger personen om en gåde.
        /// Hvis man svarer rigtigt åbner rummet sig.
        /// </summary>
        /// <param name="command"></param>
           private void svar(Command command)
           {
               Room nextRoom = currentRoom.getExit("sydøst");             
             
               if (!command.hasSecondWord() || currentRoomCharacters == null || !currentRoomCharacters.ContainsValue(characterToAsk))
               {              
                   Console.WriteLine("Hvad vil du svare`på?");
                   return;
               }

               if (characterToAsk.haveYouAnswered == true)
               {
                   Console.WriteLine("Du har allerede svaret på det spørgsmål, og dørmanden gider ikke bruge mere tid på dig");

                   return;
               }
               else if (currentPerson.drunkness == 0 && currentPerson.difficulty == "Svær")
               {
                   Console.WriteLine("Barbie er ikke fuld nok til være intellektuel, og kan endnu ikke svare på spørgsmålet endnu");
                   return;
               }
               else if (currentPerson.drunkness == 100 || currentPerson.Mæthed == 0)
               {
                   if (currentPerson.drunkness == 100)
                       Console.WriteLine("Barbie er blevet for fuld til at svare på spørgsmålet, og bliver nød til at brække sig før hun kan svare");
                   else Console.WriteLine("Barbie er for sulten til at koncentrere sig om at svare på spørgsmålet");
                   return;
               }
               else if (command.SecondWord == characterToAsk.getAnswer(currentQuestion) && currentRoom.getRoomName() == "Herr Bartels")
               {
                   //Hvis du svarer rigtigt og står foran Herr Bartels bliver døren åbnet.
                   nextRoom = currentRoom.getExit("sydvest");
                   Console.WriteLine("Du svarede rigtigt, og dørmanden åbner nu døren til Herr Bartels"+"\n"+"Indgangen til Herr Bartels er til sydvest");
                   
               }               //Hvis du svarer forkert kommer du tilbage til Lilletorv og får en straf i point.
               else if (command.SecondWord == characterToAsk.getAnswer(currentQuestion) && currentRoom.getRoomName() == "Hornslet bar") 
               {

                   nextRoom = currentRoom.getExit("sydvest");
                   Console.WriteLine("Du svarede rigtigt, og dørmanden åbner nu døren til Hornslet bar "+"\n"+"Indgangen til Hornslet bar er til sydvest");
               }
               else 
               {
                   // Man kommer ind på den forkerte bar
                   nextRoom = currentRoom.getExit("sydøst");
                   currentRoom = nextRoom;
                   Console.WriteLine(currentRoom.getDescription());

                    // Bliver automatisk sendt til lilletorv
                   currentRoom = allRooms["Lilletorv"];
                   lastRoom = currentRoom;                  
                   Console.WriteLine(currentRoom.getLongDescription());
                   currentPerson.currentScore = currentPerson.currentScore - 200;

                   characterToAsk.haveYouAnswered = false;
                   return;
               }
               nextRoom.changeAccess();
               textWriter.changeAccess(nextRoom);
               textWriter.questionAnswered(currentRoom);
               
           }

           //Transporterer dig til et tilfældigt rum, hvis du er i nærheden af veninderne.
           public void transport()
           {
               Random room = new Random();
               int randomRoom = room.Next(1, allRooms.Count - 1);
               Room nextRoom = currentRoom.getTransport(randomRoom.ToString());
               currentRoom = nextRoom;
               lastRoom = currentRoom;
               if (currentRoom.getRoomName() == "CastenSkjold" || currentRoom.getRoomName() == "Heidis" || currentRoom.getRoomName() =="A-bar")
                   return;
               else Console.WriteLine(currentRoom.getLongDescription());
           }

        /// <summary>
           /// Gemmer spillet i en ny fil
        /// </summary>
        /// <param name="command"></param>

           public void save(Command command)
           {
               textWriter.writeCurrentRoom(currentRoom);
               textWriter.setPerson(currentPerson);
               string currentGamePath = @"..\..\Properties\CurrentGame.txt";
               bool succes = false;
               Console.WriteLine("Skriv et navn til dit gemte spil");
               string savedGames = textReader.getSavedGames();
               
               Console.WriteLine("Gemte spil: " + savedGames);
               TextReader reader = Console.In;
               Console.Write("> ");
               string inputLine = reader.ReadLine();

               string[] words = inputLine.Split(' ');
               string whereToSafe = @"..\..\Properties\SaveGames\" + words[0] + ".txt";
               if (!File.Exists(whereToSafe))
               {
                   succes = true;

                   using (StreamWriter writer = File.AppendText(@"..\..\Properties\SavedGames.txt"))
                   {
                       writer.WriteLine();
                       writer.WriteLine("SAVE#" + words[0]+"#"+currentPerson.difficulty);
                   }
               }
               if (File.Exists(whereToSafe)) 
               {
                   Console.WriteLine("Vil overskrive din tidligere gemte fil?");
                   Console.WriteLine("Ja eller nej");
                   Console.Write("> ");
                   inputLine = reader.ReadLine();

                   if (inputLine == "ja" || inputLine == "Ja")
                   {
                       succes = true;
                       textWriter.overwriteSave(words[0], currentPerson);
                   }
                  
                   
               }

               // Tjekker om det er lykkedes at gemme spillet i en fil, hvis det er, 
               if (succes == true)
               {
                   Console.WriteLine("Dit spil er nu gemt");
                   File.Copy(currentGamePath, whereToSafe, true);

               }
               Console.WriteLine(currentRoom.getLongDescription());
           }

        /// <summary>
           /// Henter spillet fra en bestemt fil
        /// </summary>
        /// <param name="command"></param>

           public void load(Command command) 
           {
               string savedGames = textReader.getSavedGames();

               Console.WriteLine("Skriv navnet på det spil du gerne vil hente. Gemte spil: " + savedGames);
               TextReader reader = Console.In;
               Console.Write("> ");
               string inputLine = reader.ReadLine();
               string[] words = inputLine.Split(' ');

               string loadPath = @"..\..\Properties\SaveGames\" + words[0] + ".txt";
               string currentGamePath = @"..\..\Properties\CurrentGame.txt";
               if (File.Exists(loadPath))
               {
                   Console.WriteLine("Er du sikker på at du vil loade det gemte spil");
                   Console.WriteLine("Ja eller nej");
                   Console.Write("> ");
                   inputLine = reader.ReadLine();

                   if (inputLine == "ja" || inputLine == "Ja")
                   {
                       File.Copy(loadPath, currentGamePath, true);
                       textReader.setSaveGame(currentPerson, allRooms, allCharacters, allTransports);
                       string roomName = textReader.getRoomName(loadPath);
                       currentRoom = allRooms[roomName];
                       currentRoomCharacters = currentRoom.getCharacters();
                       if (currentPerson.difficulty == "Svær")
                           randomDude = allCharacters["RandomDude"];
                   }
                       

               }
               else Console.WriteLine("Denne fil eksisterer ikke");
               Console.WriteLine(currentRoom.getLongDescription());
           }
    }
 }

